#include <bits/stdc++.h>
using namespace std;
void A();
void X1();
void X2();

int i=0, f = 0;
char str[10];
int l;

int main()
{
    printf("CFG is: \nA->aXd\nX->bbX\nX->bcX\nX->e\n");
    printf("Enter your string: ");
    scanf("%s", &str);

    l = strlen(str);
    if(l>=2)
    {
        A();
    }
    else
    {
        printf("String is invalid\n");
    }
    //printf("l: %d i:%d f:%d\n",l,i,f);
    if(l == i && f)
    {
        printf("String is valid\n");
    }
    else
    {
        printf("String is invalid\n");
    }
    return 0;
}
void A()
{
    if (str[i] == 'a')
    {
        i++;
        if(str[i+1] == 'b')
        {
            X1();
        }
        else if(str[i+1] == 'c')
        {
            X2();
        }
        else if(str[i] == 'd' && l ==2)
        {
            f=1;
            i++; //for equaling length
            return;
        }
        else
        {
            f = 0;
            return;
        }
    }
    else
    {
       f = 0;
       return;
    }
}
void X1()
{
    if (str[i] == 'b' && str[i+1] == 'b')
    {
        i = i+2;
        if(str[i] == 'd')
        {
            f = 1;
            i++;
            return;
        }
        else
        {
            if(str[i+1] == 'b')
            {
                X1();
            }
            else if(str[i+1] == 'c')
            {
                X2();
            }
        }
    }
    else
    {
        f=0;
        return;
    }
}
void X2()
{
    if (str[i] == 'b' && str[i+1] == 'c')
    {
        i = i+2;
        if(str[i] == 'd')
        {
            f = 1;
            i++;
            return;
        }
        else
        {
            if(str[i+1] == 'b')
            {
                X1();
            }
            else if(str[i+1] == 'c')
            {
                X2();
            }
        }
    }
    else
    {
        f=0;
        return;
    }
}

