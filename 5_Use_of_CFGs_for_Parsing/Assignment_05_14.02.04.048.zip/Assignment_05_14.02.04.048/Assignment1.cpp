#include <bits/stdc++.h>
using namespace std;
void S();
void A();
void B();

int i, f = 0;
char str[10];
int l;

int main()
{
    printf("CFG is: \nS-> b|AB\nA->a|aA\nB->b\n");
    printf("Enter your string: ");
    scanf("%s", &str);

    l = strlen(str);
    if(l>=1)
    {
        S();
    }
    else
    {
        printf("String is invalid\n");
    }
    if(l == i && f)
    {
        printf("String is valid\n");
    }
    else
    {
        printf("String is invalid\n");
    }
    return 0;
}
void S()
{
    if (str[i] == 'b')
    {
        i++;
        f=1;
        return;
    }
    else
    {
        A();
        if (f)
        {
            B();
            return;
        }
    }
}
void A()
{
    if (str[i] == 'a')
    {
        i++;
        f=1;
    }
    else
    {
        f=0;
        return;
    }
    if (i<l-1) A();
}
void B()
{
    if (str[i] == 'b')
    {
        i++;
        f=1;
        return;
    }
    else
    {
        f=0;
        return;
    }
}
