#include <bits/stdc++.h>
using namespace std;

typedef struct Table
{
    char producer[5];
    char production[30];
    char first[30];
    char follow[30];
};
int findProduction(Table t1[], char c[], int currentPosition, int maxPosition);

int main(void)
{
    FILE *p1;
    Table t1[20];
    char c, d, lex[100];
    int maxProducer = 0;


    //initializing structure
    p1 = fopen("input.txt", "r");

    if(!p1) printf("\nFile can't be opened!");
    else
    {
        int i = 0;
        while((c = fgetc(p1))!=EOF)
        {
            if( c == ' ')
            {
                lex[i] = '\0';
                strcpy(t1[maxProducer].producer,lex);
                memset(lex, '\0', sizeof(lex));
                i = 0;
            }
            else if(c == '\n')
            {
                lex[i] = '\0';
                strcpy(t1[maxProducer].production,lex);
                memset(lex, '\0', sizeof(lex));
                maxProducer++;
                i = 0;
            }
            else
            {
                lex[i++] = c;
            }
        }
    }
    /*for(int x=0; x<maxProducer; x++)
    {
        printf("%s->%s\n",t1[x].producer, t1[x].production);
    }*/

    //find the first
    for(int x=0; x<maxProducer; x++)
    {
        int firstCursor = 0,productionCursor = 0;
        int y = x;
        while(t1[y].production[0] >= 'A' && t1[y].production[0] <='Z')
        {
            y = findProduction(t1, t1[y].production, y, maxProducer);
        }
        t1[x].first[firstCursor++]=t1[y].production[productionCursor];
        int flag = 1;
        while(t1[y].production[productionCursor]!='|')
        {
            productionCursor++;
            if(strlen(t1[y].production) == productionCursor)
            {
                flag = 0;
                break;
            }
        }
        if(flag)
        {
            productionCursor++;
            while(strlen(t1[y].production) != productionCursor)
            {
                t1[x].first[firstCursor++]=t1[y].production[productionCursor++];
            }
        }
        t1[x].first[firstCursor]='\0';
    }
    /*for(int x=0; x<maxProducer; x++)
    {
        printf("%s->%s \nFirst of(%s):%s\n",t1[x].producer, t1[x].production, t1[x].producer, t1[x].first);
    }*/

    //finding follow
    for(int x=0; x<maxProducer; x++)
    {
        int y;
        for(y=0; y<strlen(t1[x].production); y++)
        {
            if(t1[x].production[y] == '|')
                break;
        }
        if(y < strlen(t1[x].production))
        {
            t1[x].production[strlen(t1[x].production)+1] = '\0';
            for(int j = strlen(t1[x].production); j>y ; j--)
            {
                t1[x].production[j] = t1[x].production[j-1];
            }
            t1[x].production[y] = '$';
        }
        else
        {
            t1[x].production[strlen(t1[x].production)] = '$';
            t1[x].production[strlen(t1[x].production)+1] = '\0';
        }
        memset(t1[x].follow, '\0', sizeof(t1[x].follow));
    }
    for(int x=0; x<maxProducer; x++)
    {
        int y = 0, j = 0;
        while(t1[y].production[j] != t1[x].producer[0])
        {
            j++;
            if(j == strlen(t1[y].production))
            {
                y++;
                j = 0;
            }
            if(y == maxProducer)
            {
                break;
            }
        }
        //printf("for production: %c match found: %c\n",t1[x].producer[0],t1[y].production[j+1]);
        int followCoursor = 0;

        if(x == 0)
        {
            t1[x].follow[followCoursor++] = '$';
        }

        if(t1[y].production[j+1]=='$')
        {
            //printf("producer we get %s and follw : %s\n",t1[y].producer,t1[y].follow);
            strcat(t1[x].follow, t1[y].follow);
            followCoursor = strlen(t1[x].follow);
            //printf("for %s, follow: %s\n", t1[x].producer,t1[y].follow);
            //printf("in if\n");
        }
        else if(t1[y].production[j+1]>='A' && t1[y].production[j+1]<='Z')
        {
            //printf("in elseif\n");
            char tempArray[2];
            tempArray[0] = t1[y].production[j+1];
            tempArray[1] = '\0';

            int p = findProduction(t1, tempArray, 0, maxProducer);
            //printf("%d\n",p);

            strcat(t1[x].follow, t1[p].first);
            //printf("producer :%s new genarated follow: %s\n",t1[x].producer,t1[x].follow);

            int flag = 0;
            int m, z;
            for(m=0;m<strlen(t1[x].follow);m++)
            {
                if(t1[x].follow[m]=='#')
                {
                    flag = 1;
                    break;
                }
            }
            if(flag)
            {
                for(followCoursor = m, z =0; z<strlen(t1[y].follow); followCoursor++,z++)
                {
                    t1[x].follow[followCoursor] = t1[y].follow[z];
                }
            }
            //printf("producer :%s new genarated follow: %s\n",t1[x].producer,t1[x].follow);

        }
        else
        {
            //printf("in else\n");
            t1[x].follow[followCoursor++] = t1[y].production[j+1];
        }
        t1[x].follow[followCoursor] = '\0';
    }
    {
        for(int x=0; x<maxProducer; x++)
        {
            printf("%s->%s\n",t1[x].producer, t1[x].production);
        }
        printf("\n");
        for(int x=0; x<maxProducer; x++)
        {
            printf("First of(%s): ",t1[x].producer);
            printf("{ ");
            for(int i=0; i<strlen(t1[x].first);i++)
            {
                if(t1[x].first[i]=='i')
                {
                    printf("id");
                    i++;
                }
                else
                {
                    printf("%c",t1[x].first[i]);
                }
                if(i<strlen(t1[x].first)-1)
                {
                    printf(",");
                }
            }
            printf(" }\n");
        }
        printf("\n");
        for(int x=0; x<maxProducer; x++)
        {
            //printf("Follow of (%s): %s\n",t1[x].producer, t1[x].follow);
            printf("Follow of(%s): ",t1[x].producer);
            printf("{ ");
            for(int i=0; i<strlen(t1[x].follow);i++)
            {
                printf("%c",t1[x].follow[i]);
                if(i<strlen(t1[x].follow)-1)
                {
                    printf(",");
                }
            }
            printf(" }\n");
        }
    }
    return 0;

}

int findProduction(Table t1[], char c[],int currentPosition, int maxPosition)
{
    for(int i = currentPosition+1 ; i< maxPosition; i++)
    {
        if(t1[i].producer[0]==c[0])
        {
            return i;
        }
    }
}
//input file must contain a newline at the end
//input file can contain highest one or
