#include <stdio.h>
int                   main(void)
{
    //this is a single line comment
    //this is an another comment
    printf("Hello / World!!"); //Single line
    /*this
    is
    multiple
     line comment */
}
