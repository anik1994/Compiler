#include <stdio.h>

int main(void)
{
    FILE *p1, *p2;
    char c, d;
    int numberOfSpace = 0;
    bool isComment = false, singleLine = false, multipleLine = false;

    p1 = fopen("input.cpp", "r");
    p2 = fopen("temp.txt", "w");

    if(!p1) printf("\nFile can't be opened!");
    else
    {
        while((c = fgetc(p1)) != EOF)
        {

            if(isComment)
            {
                if(singleLine)
                {
                    if(c == '\n')
                    {
                        isComment = false;
                        singleLine = false;
                    }
                }
                if(multipleLine)
                {
                    if(c == '*')
                    {
                        d = fgetc(p1);
                        if(d == '/')
                        {
                            isComment = false;
                            multipleLine = false;
                        }
                    }
                }
            }
            else
            {
                if(c == '\n')
                {
                    fputc(' ',p2);
                    numberOfSpace = 0;
                }
                else if(c == '/')
                {
                    d = fgetc(p1);
                    if( c == '/' && d == '/')
                    {
                        isComment = true;
                        singleLine = true;
                    }
                    else if( c == '/' && d == '*')
                    {
                        isComment = true;
                        multipleLine = true;
                    }
                    else
                    {
                        fputc(c,p2);
                        fputc(d,p2);
                    }
                }
                else if(c == ' ')
                {
                    if(!numberOfSpace)
                    {
                        fputc(' ',p2);
                        numberOfSpace++;
                    }
                    else
                        numberOfSpace++;

                }
                else
                {
                    fputc(c,p2);
                    numberOfSpace = 0;
                }
            }

            /*if((c == '{') || (c == '}'))
                {
                    fputc(c,p2);
                }*/
        }
    }
    fclose(p1);
    fclose(p2);

    p1 = fopen("temp.txt", "r");
    p2 = fopen("output.txt", "w");
    while((c = fgetc(p1))!=EOF)
    {
        if(c == ' ')
        {
            d = fgetc(p1);
            if(d != ' ')
            {
                fputc(c,p2);
                fputc(d,p2);
            }
        }
        else
        {
            fputc(c,p2);
        }
    }
    fclose(p1);
    fclose(p2);


    p2 = fopen("input.cpp", "r");
    while((c = fgetc(p2))!=EOF)
        printf("%c", c);
    fclose(p2);
    printf("\n\n");
    p2 = fopen("output.txt", "r");
    while((c = fgetc(p2))!=EOF)
        printf("%c", c);
    fclose(p2);

    return 0;
}
