#include <bits/stdc++.h>
int isSeparetor(char);
int isOperator(char);
int isKeyword(char []);
int num_rec(char []);
int id_rec(char []);
int operator_rec(char []);
int separator_rec(char []);
int par_rec(char []);

int main()
{
    FILE *p1, *p2;
    char c, prevC, lex[100];
    int index;
    {
        //for separator
        p1 = fopen("input.txt", "r");
        p2 = fopen("temp.txt", "w");

        if(!p1) printf("\nFile can't be opened!");
        else
        {
            while((c = fgetc(p1))!=EOF)
            {
                if(isSeparetor(c))
                {
                    if(prevC != ' ')
                    {
                        fputc(' ',p2);
                        fputc(c,p2);
                        prevC = c;
                    }
                    else
                    {
                        fputc(c,p2);
                        prevC = c;
                    }
                }
                else
                {
                    if(isSeparetor(prevC) && c != ' ')
                    {
                        fputc(' ',p2);
                        fputc(c,p2);
                        prevC = c;
                    }
                    else
                    {
                        fputc(c,p2);
                        prevC = c;
                    }
                }
            }
        }
        fclose(p1);
        fclose(p2);
    }

    {
        //for operator
        p1 = fopen("temp.txt", "r");
        p2 = fopen("tempOp.txt", "w");

        if(!p1) printf("\nFile can't be opened!");
        else
        {
            while((c = fgetc(p1))!=EOF)
            {
                if(isOperator(c))
                {
                    if(!isOperator(prevC) && prevC != ' ')
                    {
                        fputc(' ',p2);
                        fputc(c,p2);
                        prevC = c;
                    }
                    else if(!isOperator(prevC) && prevC == ' ')
                    {
                        fputc(c,p2);
                        prevC = c;
                    }
                    else
                    {
                        fputc(c,p2);
                        prevC = c;
                    }
                }
                else
                {
                    if(isOperator(prevC) && c != ' ')
                    {
                        fputc(' ',p2);
                        fputc(c,p2);
                        prevC = c;
                    }
                    else
                    {
                        fputc(c,p2);
                        prevC = c;
                    }
                }
            }
        }
        fclose(p1);
        fclose(p2);

    }

    {
        //for checking lexems
        p1 = fopen("tempOp.txt", "r");
        p2 = fopen("output.txt", "w");

        if(!p1) printf("\nFile can't be opened!");
        else
        {
            index = 0;
            while((c = fgetc(p1))!=EOF)
            {
                if(c==' ')
                {
                    lex[index]='\0';
                    if(isKeyword(lex))
                    {
                        fprintf(p2,"[kw %s]",lex);
                        printf("%s is a keyword\n",lex);
                    }
                    else if(id_rec(lex))
                    {
                        fprintf(p2,"[id %s]",lex);
                        printf("%s is a id\n",lex);
                    }
                    else if(num_rec(lex))
                    {
                        fprintf(p2,"[num %s]",lex);
                        printf("%s is a number\n",lex);
                    }
                    else if(operator_rec(lex))
                    {
                        fprintf(p2,"[op %s]",lex);
                        printf("%s is a operator\n",lex);
                    }
                    else if(separator_rec(lex))
                    {
                        fprintf(p2,"[sep %s]",lex);
                        printf("%s is a separator\n",lex);
                    }
                    else if(par_rec(lex))
                    {
                        fprintf(p2,"[par %s]",lex);
                        printf("%s is a par\n",lex);
                    }
                    else
                    {
                        fprintf(p2,"[unkn %s]",lex);
                        printf("%s unknown\n",lex);
                    }
                    index = 0;
                    memset(lex, '\0', sizeof(lex));
                }
                else
                {
                    lex[index]=c;
                    index++;
                }
            }
        }
        fclose(p1);
        fclose(p2);
    }

    return 0;

}

int operator_rec(char lex[])
{
    char operators[] = "+-*/%<>?&|!=";
    int i=0,flag=0;
    int len = strlen(operators);
    for(i=0;i<len;i++)
    {
        if(lex[0]==operators[i])
        {
            flag = 1;
            break;
        }
    }
    return flag;
}
int separator_rec(char lex[])
{
    char separetor[] = ";,:''\"";
    int i=0,flag=0;
    int len = strlen(separetor);
    for(i=0;i<len;i++)
    {
        if(lex[0]==separetor[i])
        {
            flag = 1;
            break;
        }
    }
    return flag;
}
int par_rec(char lex[])
{
    char separetor[] = "()[]{}";
    int i=0,flag=0;
    int len = strlen(separetor);
    for(i=0;i<len;i++)
    {
        if(lex[0]==separetor[i])
        {
            flag = 1;
            break;
        }
    }
    return flag;
}
int isOperator(char c)
{
    char operators[] = "+-*/%<>?&|!=";
    int i=0,flag=0;
    int len = strlen(operators);
    for(i=0;i<len;i++)
    {
        if(c==operators[i])
        {
            flag = 1;
            break;
        }
    }
    return flag; //flag 0 is not separetor
}
int isSeparetor(char c)
{
    char separetor[] = ";,:()[]{}''\"";
    int i=0,flag=0;
    int len = strlen(separetor);
    for(i=0;i<len;i++)
    {
        if(c==separetor[i])
        {
            flag = 1;
            break;
        }
    }
    return flag; //flag 0 is not separetor
}
int isKeyword(char buffer[]){
    char keywords[32][10] = {"auto","break","case","char","const","continue","default",
                            "do","double","else","enum","extern","float","for","goto",
                            "if","int","long","register","return","short","signed",
                            "sizeof","static","struct","switch","typedef","union",
                            "unsigned","void","volatile","while"};
    int i, flag = 0;

    for(i = 0; i < 32; ++i){
        if(strcmp(keywords[i], buffer) == 0){
            flag = 1;
            break;
        }
    }
    return flag;
}

int num_rec(char lex[])
{
    int i, l, s;
    i = 0;

    if(isdigit(lex[i]))
    {
        s=1;
        i++;
    }
    else
    {
        if(lex[i]=='.')
        {
            s=2;
            i++;
        }
        else
        {
            s=0;
        }
    }
    l=strlen(lex);

    if(s==1)
    {
        for(;i<l;i++)
        {
            if(isdigit(lex[i]))
                s=1;
            else
            {
                if(lex[i]=='.')
                {
                    s=2;
                    i++;
                    break;
                }
                else
                {
                    s=0;
                    break;
                }
            }
        }
    }
    if(s==2)
    {
        if(isdigit(lex[i]))
        {
            s=3;
            i++;
        }
        else
            s=0;
    }
    if(s=3)
    {
        for(;i<l;i++)
        {
            if(isdigit(lex[i]))
            {
                s=3;
            }
            else
            {
                s=0;
                break;
            }
        }
    }
    if(s==3) s=1;
    return s; //1 for num, 0 for not num
}

int id_rec(char lex[])
{
    int i, l, s;
    i = 0;
    if(isalpha(lex[i])||lex[i]=='_')
    {
        l=strlen(lex);
        for(i=1;i<l;i++)
        {
            if(isalnum(lex[i])||lex[i]=='_')
                i++;
        }
        s=1;
        return s;
    }
    else
    {
        s=0;
        return s;
    }
}
