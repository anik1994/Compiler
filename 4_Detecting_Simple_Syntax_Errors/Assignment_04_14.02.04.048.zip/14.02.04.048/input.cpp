/* A program fragment*/

float x1 = 3.125 ; ;
/* Definition of function f1 */
double f1 ( int int x )
{ if (x < x1 )
        double z ;
    else z =     0.01 + x * 5.5 ; } }
        else return z ;
}
/* Beginning of 'main' */
int main ( void )
{
   int n1 ; double z;
{ { n1 = 25 ; z = f1 ( n1 ) ; }
