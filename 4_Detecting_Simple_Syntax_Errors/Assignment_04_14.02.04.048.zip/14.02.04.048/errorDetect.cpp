#include <bits/stdc++.h>
using namespace std;
int main(void)
{
    FILE *p1, *p2;
    char c, d, lex[100];
    int index;
    int numberOfSpace = 0;
    bool isComment = false, singleLine = false, multipleLine = false;

    //line numbering
    string line;
    ifstream myfileIn("input.cpp");
    ofstream myfileOut("lineNumbering.txt");
    if (myfileIn.is_open())
    {
        int lineNumber = 0;
        while ( getline (myfileIn,line) )
        {
            lineNumber++;
            //cout << lineNumber << ' ' << line << '\n';
            myfileOut << lineNumber << ' ' << line << '\n';
        }
        myfileIn.close();
    }
    else cout << "Unable to open file";
    myfileOut.close();

    //comment delete
    p1 = fopen("lineNumbering.txt", "r");
    p2 = fopen("deletingComment.txt", "w");

    if(!p1) printf("\nFile can't be opened!");
    else
    {
        fprintf(p2, "\n");
        while((c = fgetc(p1)) != EOF)
        {

            if(isComment)
            {
                if(singleLine)
                {
                    if(c == '\n')
                    {
                        fputc('\n',p2);
                        isComment = false;
                        singleLine = false;
                    }
                }
                if(multipleLine)
                {
                    if(c == '*')
                    {
                        d = fgetc(p1);
                        if(d == '/')
                        {
                            isComment = false;
                            multipleLine = false;
                        }
                    }
                }
            }
            else
            {
                if(c == '\n')
                {
                    fputc('\n',p2);
                    numberOfSpace = 0;
                }
                else if(c == '/')
                {
                    d = fgetc(p1);
                    if( c == '/' && d == '/')
                    {
                        isComment = true;
                        singleLine = true;
                    }
                    else if( c == '/' && d == '*')
                    {
                        isComment = true;
                        multipleLine = true;
                    }
                    else
                    {
                        fputc(c,p2);
                        fputc(d,p2);
                    }
                }
                else if(c == ' ')
                {
                    if(!numberOfSpace)
                    {
                        fputc(' ',p2);
                        numberOfSpace++;
                    }
                    else
                        numberOfSpace++;

                }
                else
                {
                    fputc(c,p2);
                    numberOfSpace = 0;
                }
            }
        }
    }
    fclose(p1);
    fclose(p2);

    //tokenizing
    //balance praranthesis
    p1 = fopen("deletingComment.txt", "r");
    p2 = fopen("tokenized.txt", "w");

    char str[50], tempStr[50];
    int frame[50];
    char lnum[3];
    int number = 0, currentLine;

    if(!p1) printf("\nFile can't be opened!");
    else
    {
        while((c = fgetc(p1))!=EOF)
        {
            if(c == '\n')
            {
                if((c = fgetc(p1))!=EOF)
                {
                    lnum[0] = c;
                    lnum[1] = fgetc(p1);
                    lnum[2] = '\0';
                    currentLine = atoi(lnum);
                    fprintf(p2, "[$%d]",currentLine);
                }
                else
                    break;
            }
            else if(c == '(' || c == ')' || c == '{' || c == '}')
            {
                str[number] = c;
                frame[number] = currentLine;
                number++;
                fprintf(p2, "[%c]",c);
            }
            else
            {
                if(c == ' ')
                {
                    continue;   //bracket naoyar porer space ta nisse
                }
                int q = 0;
                tempStr[q] = c;
                bool flag = false;
                while((c = fgetc(p1))!= EOF)
                {
                    if(c == ' ')
                    {
                        break;
                    }
                    if(c == '\n' && (c = fgetc(p1))!=EOF)
                    {
                        lnum[0] = c;
                        lnum[1] = fgetc(p1);
                        lnum[2] = '\0';
                        currentLine = atoi(lnum);
                        flag = true;
                        //fprintf(p2, "[$%d]",currentLine);
                        break;
                    }
                    tempStr[++q] = c;
                }
                tempStr[++q] = '\0';
                fprintf(p2, "[%s]",tempStr);
                memset(tempStr, '\0', sizeof(tempStr));
                if(flag)
                {
                    fprintf(p2, "[$%d]",currentLine);
                }
            }
        }
    }

    fclose(p1);
    fclose(p2);
    //stack <char> braces;
    int paren = 0, curly = 0, i = 0;
    for(; i<number; i++)
    {
        if(str[i] == '(')
                paren--;
        else if(str[i] == ')')
                paren++;
        else if(str[i] == '{')
                curly--;
        else if(str[i] == '}')
                curly++;
        if(curly>=1)
        {
                printf("Misplaced } at line %d\n",frame[i]);
                curly = 0;
        }
        if(paren>=1)
        {
               printf("Misplaced ) at line %d\n",frame[i]);
               paren = 0;
        }
        //printf("%c\t %d\n", str[i], frame[i]);
    }
    if(curly!=0)
    {
        printf("Misplaced } at line %d\n",frame[i-1]);
        curly = 0;
    }
    if(paren!=0)
    {
        printf("Misplaced } at line %d\n",frame[i-1]);
        paren = 0;
    }

    //multiple tokens
    p1 = fopen("tokenized.txt", "r");

    if(!p1) printf("\nFile can't be opened!");
    else
    {
        int lineNum = 0, depth = 0, j = 0;
        char fullStirng[200][50];
        int numberOfIF = 0;

        while((c = fgetc(p1))!=EOF)
        {
            if(c == '[')
            {
                j = 0;
                while((c = fgetc(p1))!= ']')
                {
                    fullStirng[depth][j++] = c;
                }
                fullStirng[depth][j] = '\0';
                j=0;
                depth++;
            }
        }
        for(int m = 0; m<depth-1;m++)
        {
            if(fullStirng[m][0] == '$')
            {
                lineNum++;
            }
            else
            {
                int compareWithTwoString = strcmp(fullStirng[m],fullStirng[m+1]);
                int compareWithOpeningParam = strcmp(fullStirng[m],"(");
                int compareWithClosingParam = strcmp(fullStirng[m],")");
                int compareWithOpeningBraces = strcmp(fullStirng[m],"{");
                int compareWithClosingBraces = strcmp(fullStirng[m],"}");
                if(compareWithTwoString == 0 && compareWithOpeningParam != 0 && compareWithClosingParam != 0 && compareWithOpeningBraces != 0 && compareWithClosingBraces != 0)
                {
                    printf("Duplicate Token at line %d\n", lineNum);
                }

                //ifElse miss match
                int compareWithIf = strcmp(fullStirng[m], "if");
                int compareWithElse = strcmp(fullStirng[m], "else");
                if(compareWithIf == 0)
                {
                    numberOfIF++;
                }
                if(compareWithElse == 0)
                {
                    numberOfIF--;
                }
                if(numberOfIF < 0)
                {
                    printf("Unmatched ELSE at line %d\n",lineNum);
                    numberOfIF = 0;
                }
            }
            //printf("%s\n",fullStirng[m]);
        }
    }
    fclose(p1);

    return 0;
}
