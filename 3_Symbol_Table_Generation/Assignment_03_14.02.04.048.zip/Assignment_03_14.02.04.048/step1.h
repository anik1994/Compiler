void makeTokenSteam(FILE *p1, FILE *p2, FILE *p3)
{
    if(!p1) printf("\nFile can't be opened!");
    else
    {
        while((c = fgetc(p1))!=EOF)
        {
            if(c == '[')
            {
                fputc('[',p2);
                fputc('[',p3);
                index = 0;
                while((c=fgetc(p1))!=' ')
                {
                    lex[index] = c;
                    index++;
                }
                lex[index] = c;
                index++;
                if(strcmp(lex,"id ")==0)
                {
                    while((c=fgetc(p1))!=']')
                    {
                        lex[index] = c;
                        index++;
                    }
                }
                else
                {
                    index = 0;
                    memset(lex, '\0', sizeof(lex));
                    while((c=fgetc(p1))!=']')
                    {
                        lex[index] = c;
                        index++;
                    }
                }
                fprintf(p2,"%s]",lex);
                fprintf(p3,"%s]",lex);
                memset(lex, '\0', sizeof(lex));
            }
        }
    }
    fprintf(p3,"\n\n");
    fclose(p1);
    fclose(p2);
    fclose(p3);
}
