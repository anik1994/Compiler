void symbolTableGeneration(FILE *p1, FILE *p2)
{
    if(!p1) printf("\nFile can't be opened!");
    else
    {
        while((c=fgetc(p1)) != EOF)
        {
            if(c=='[')
            {
                index = 0;
                memset(lex, '\0', sizeof(lex));
                while((c=fgetc(p1))!=']')
                {
                    lex[index] = c;
                    index++;
                }
                lex[index] = '\0';
                int temp; //for getting string index
                if(dataTypeRec(lex))
                {
                    currentNO++;
                    t1[currentNO].slNo = currentNO;
                    strcpy(t1[currentNO].dataType, lex);
                    loadNextLex(p1);
                    if((temp = isName(nextLex)) > 0)
                    {
                        int i,tempIndex;
                        for(i = temp, tempIndex = 0; i < strlen(nextLex); i++, tempIndex++)
                        {
                            t1[currentNO].name[tempIndex] = nextLex[i];
                        }
                        t1[currentNO].name[tempIndex] = '\0';
                        loadNextLex(p1);
                        changeScope(nextLex,t1);

                        if(strcmp(nextLex,"(") == 0)
                        {
                            t1[currentNO].type = "func";
                            t1[currentNO].scope = currentFun;
                            currentFun = t1[currentNO].name;
                        }
                        else
                        {
                            t1[currentNO].type = "var";
                            t1[currentNO].scope = currentFun;
                        }
                    }
                    else
                    {
                        changeScope(nextLex,t1);
                    }
                }
                else
                {
                    changeScope(lex,t1);
                }
            }
        }

        for(int x =1; x <= currentNO; x++)
        {
            fprintf(p2,"%d\t%s\t%s\t%s\t%s\n",t1[x].slNo,t1[x].name,t1[x].type,t1[x].dataType,t1[x].scope);
        }
    }
    fprintf(p2,"\n");
    fclose(p1);
    fclose(p2);

}
