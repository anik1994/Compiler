void modifiedTokens(FILE *p1, FILE *p2)
{
    if(!p1) printf("\nFile can't be opened!");
    else
    {
        char *currentScope = "global";
        while((c=fgetc(p1)) != EOF)
        {
            if(c=='[')
            {
                fputc('[',p2);
                index = 0;
                memset(lex, '\0', sizeof(lex));
                while((c=fgetc(p1))!=']')
                {
                    lex[index] = c;
                    index++;
                }
                lex[index] = '\0';
                int temp; //for getting string index
                if((temp = isName(lex)) > 0)
                {
                    int i,tempIndex;
                    char str[20];
                    for(i = temp, tempIndex = 0; i < strlen(lex); i++, tempIndex++)
                    {
                        str[tempIndex] = lex[i];
                    }
                    str[tempIndex] = '\0';
                    for(int i = 1; i <= currentNO; i++)
                    {
                        if(strcmp(t1[i].name, str) == 0 && strcmp(t1[i].scope, currentScope) == 0)
                        {
                            fprintf(p2,"id %d]",i);
                            if(strcmp(t1[i].type, "func") == 0)
                            {
                                currentScope = t1[i].name;
                            }
                        }
                        else if(strcmp(t1[i].name, str) == 0 && strcmp(t1[i].scope, currentScope) != 0 && strcmp(t1[i].type, "func") == 0)
                        {
                            fprintf(p2,"id %d]",i);
                        }
                    }
                }
                else if(strcmp("}",lex) == 0)
                {
                    currentScope = "global";
                    fprintf(p2,"}]");
                }
                else
                {
                    fprintf(p2,"%s",lex);
                    fputc(']',p2);
                }
            }
            else
            {
                fputc(c,p2);
            }
        }
    }
    fclose(p1);
    fclose(p2);
}
