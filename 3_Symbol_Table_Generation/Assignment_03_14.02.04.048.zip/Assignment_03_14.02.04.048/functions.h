void changeScope(char buffer[],Table t1[])
{
    if(strcmp(buffer,"}") == 0)
    {
        int x = currentNO - 1;
        while(strcmp(currentFun, t1[x].scope) == 0)
        {
            x--;
        }
        currentFun = t1[x].scope;
    }
}

void loadNextLex(FILE *p)
{
    char c;
    int index;
    while((c=fgetc(p)) != EOF)
    {
        if(c=='[')
        {
            index = 0;
            memset(nextLex, '\0', sizeof(nextLex));
            while((c=fgetc(p))!=']')
            {
                nextLex[index] = c;
                index++;
            }
            nextLex[index] = '\0';
            return ;
        }
    }
}


int isName(char buffer[])
{
    char x, tempStr[50];
    int i;
    for(i = 0; i < strlen(buffer); i++)
    {
        if(buffer[i] == ' ')
        {
            tempStr[i] = '\0';
            if(strcmp(tempStr, "id") == 0)
            {
                return i+1;
            }
        }
        else
        {
            tempStr[i]=buffer[i];
        }
    }
    return 0;
}


int dataTypeRec(char buffer[])
{
    char dataTypes[3][10] = {"double", "float", "int"};
    int i, flag = 0;

    for(i = 0; i < 3; ++i)
    {
        if(strcmp(dataTypes[i], buffer) == 0)
        {
            flag = 1;
            break;
        }
    }
    //printf("flag Value: %d\n", flag);
    return flag;
}

void printOutput(FILE *p)
{
    if(!p) printf("\nFile can't be opened!");
    else
    {
        while((c = fgetc(p))!=EOF)
        {
            printf("%c",c);
        }
    }
    fclose(p);
}
