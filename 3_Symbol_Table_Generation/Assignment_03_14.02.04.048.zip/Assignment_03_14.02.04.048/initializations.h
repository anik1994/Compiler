typedef struct Table
{
    int slNo;
    char name[25];
    char *type;
    char dataType[25];
    char *scope;
};

int currentNO = 0;
char *currentFun = "global";
char nextLex[50];

char c, lex[100];
Table t1[20];
int index;
