#include <bits/stdc++.h>
#include "initializations.h"
#include "functions.h"
#include "step1.h"
#include "step2.h"
#include "step3.h"
using namespace std;

int main(void)
{
    FILE *p1, *p2, *p3;

    //step 1
    p1 = fopen("input.txt", "r");
    p2 = fopen("temp.txt", "w");
    p3 = fopen("output.txt","w");

    fprintf(p3,"Step 1:\n");
    makeTokenSteam(p1, p2, p3);

    //step 2
    p1 = fopen("temp.txt","r");
    p2 = fopen("output.txt","a");

    fprintf(p2,"Step 2:\n");
    symbolTableGeneration(p1, p2);

    //step 3
    p1 = fopen("temp.txt","r");
    p2 = fopen("output.txt","a");

    fprintf(p2,"Step 3:\n");
    modifiedTokens(p1, p2);

    //print the output
    p1 = fopen("output.txt","r");

    printOutput(p1);

    return 0;
}


